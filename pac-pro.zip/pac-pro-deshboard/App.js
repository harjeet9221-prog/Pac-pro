import React, { useState, useContext, createContext, useEffect } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  FlatList,
  TextInput,
  Modal,
  TouchableOpacity,
  StyleSheet,
  Button,
  Alert,
  ScrollView,
} from 'react-native';
import { VictoryPie, VictoryLine } from 'victory-native';

// Context per stato globale portafoglio ed ETF
const PortfolioContext = createContext();

const sampleETFData = [
  {
    id: '1',
    name: 'iShares Core MSCI World',
    isin: 'IE00B4L5Y983',
    category: 'Azionario Globale',
    ter: 0.20,
    description: 'ETF globale large/mid cap',
    amount: 1000,
    weight: 25,
  },
  {
    id: '2',
    name: 'Vanguard FTSE All-World',
    isin: 'IE00B3RBWM25',
    category: 'Azionario Globale',
    ter: 0.22,
    description: 'Ampia copertura globale',
    amount: 800,
    weight: 20,
  },
  {
    id: '3',
    name: 'Xtrackers MSCI Emerging Markets',
    isin: 'IE00BTJRMP35',
    category: 'Emergenti',
    ter: 0.18,
    description: 'Mercati emergenti',
    amount: 600,
    weight: 15,
  },
  {
    id: '4',
    name: 'SPDR Gold Shares',
    isin: 'US78463V1070',
    category: 'Materie Prime',
    ter: 0.40,
    description: 'ETF Oro fisico',
    amount: 400,
    weight: 10,
  },
];

function PortfolioProvider({ children }) {
  const [etfs, setEtfs] = useState(sampleETFData);
  const [portfolioAge, setPortfolioAge] = useState(3.2);
  const [monthlyContribution, setMonthlyContribution] = useState(250);

  // Calcolo valore totale e TER medio ponderato
  const totalValue = etfs.reduce((acc, etf) => acc + etf.amount, 0);
  const weightedTER =
    etfs.reduce((acc, etf) => acc + etf.ter * etf.weight, 0) / 100;

  // Funzione per aggiungere o modificare ETF
  const upsertETF = (etf) => {
    setEtfs((prev) => {
      const index = prev.findIndex((e) => e.id === etf.id);
      if (index > -1) {
        const newArray = [...prev];
        newArray[index] = etf;
        return newArray;
      }
      return [...prev, etf];
    });
  };

  return (
    <PortfolioContext.Provider
      value={{
        etfs,
        upsertETF,
        totalValue,
        weightedTER,
        portfolioAge,
        monthlyContribution,
        setPortfolioAge,
        setMonthlyContribution,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
}

function Dashboard() {
  const {
    totalValue,
    weightedTER,
    portfolioAge,
    monthlyContribution,
  } = useContext(PortfolioContext);

  return (
    <View style={styles.dashboard}>
      <Text style={styles.header}>Dashboard PAC Pro</Text>
      <View style={styles.summaryRow}>
        <View style={styles.summaryCard}>
          <Text style={styles.metricLabel}>Valore Totale (€)</Text>
          <Text style={styles.metricValue}>{totalValue.toFixed(2)}</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.metricLabel}>TER Medio (%)</Text>
          <Text style={styles.metricValue}>{(weightedTER * 100).toFixed(2)}</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.metricLabel}>Contributo Mensile (€)</Text>
          <Text style={styles.metricValue}>{monthlyContribution}</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.metricLabel}>Anni di PAC</Text>
          <Text style={styles.metricValue}>{portfolioAge}</Text>
        </View>
      </View>
    </View>
  );
}

function ETFList({ onEdit }) {
  const { etfs } = useContext(PortfolioContext);
  const [search, setSearch] = useState('');

  const filteredEtfs = etfs.filter(
    (etf) =>
      etf.name.toLowerCase().includes(search.toLowerCase()) ||
      etf.isin.toLowerCase().includes(search.toLowerCase()) ||
      etf.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={styles.etfListContainer}>
      <Text style={styles.sectionHeader}>Lista ETF</Text>
      <TextInput
        style={styles.searchInput}
        placeholder="Cerca ETF per nome, ISIN o categoria..."
        value={search}
        onChangeText={setSearch}
      />
      <FlatList
        data={filteredEtfs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.etfItem}
            onPress={() => onEdit(item)}
          >
            <View>
              <Text style={styles.etfName}>{item.name}</Text>
              <Text style={styles.etfDetails}>
                ISIN: {item.isin} | Categoria: {item.category}
              </Text>
              <Text style={styles.etfDescription}>{item.description}</Text>
            </View>
            <View style={styles.etfAmounts}>
              <Text>€ {item.amount.toFixed(2)}</Text>
              <Text>TER: {item.ter}%</Text>
              <Text>Peso: {item.weight}%</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function ETFModal({ visible, onClose, etfToEdit }) {
  const { upsertETF } = useContext(PortfolioContext);

  const isNew = !etfToEdit;
  const [name, setName] = useState(etfToEdit ? etfToEdit.name : '');
  const [isin, setIsin] = useState(etfToEdit ? etfToEdit.isin : '');
  const [category, setCategory] = useState(etfToEdit ? etfToEdit.category : 'Azionario Globale');
  const [ter, setTer] = useState(etfToEdit ? etfToEdit.ter.toString() : '0.20');
  const [description, setDescription] = useState(etfToEdit ? etfToEdit.description : '');
  const [amount, setAmount] = useState(etfToEdit ? etfToEdit.amount.toString() : '1000');
  const [weight, setWeight] = useState(etfToEdit ? etfToEdit.weight.toString() : '0');

  useEffect(() => {
    if (etfToEdit) {
      setName(etfToEdit.name);
      setIsin(etfToEdit.isin);
      setCategory(etfToEdit.category);
      setTer(etfToEdit.ter.toString());
      setDescription(etfToEdit.description);
      setAmount(etfToEdit.amount.toString());
      setWeight(etfToEdit.weight.toString());
    } else {
      setName('');
      setIsin('');
      setCategory('Azionario Globale');
      setTer('0.20');
      setDescription('');
      setAmount('1000');
      setWeight('0');
    }
  }, [etfToEdit]);

  const handleSave = () => {
    if (!name || !isin) {
      Alert.alert('Errore', 'Compila i campi Nome e ISIN');
      return;
    }
    const newETF = {
      id: isNew ? Date.now().toString() : etfToEdit.id,
      name,
      isin,
      category,
      ter: parseFloat(ter),
      description,
      amount: parseFloat(amount),
      weight: parseFloat(weight),
    };
    upsertETF(newETF);
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <ScrollView contentContainerStyle={styles.modalContent}>
        <Text style={styles.modalTitle}>{isNew ? 'Aggiungi ETF' : 'Modifica ETF'}</Text>
        <TextInput
          placeholder="Nome ETF"
          style={styles.input}
          value={name}
          onChangeText={setName}
        />
        <TextInput
          placeholder="ISIN"
          style={styles.input}
          value={isin}
          onChangeText={setIsin}
          autoCapitalize="characters"
        />
        <TextInput
          placeholder="Categoria"
          style={styles.input}
          value={category}
          onChangeText={setCategory}
        />
        <TextInput
          placeholder="TER (%)"
          style={styles.input}
          value={ter}
          onChangeText={setTer}
          keyboardType="numeric"
        />
        <TextInput
          placeholder="Descrizione"
          style={[styles.input, { height: 80 }]}
          value={description}
          onChangeText={setDescription}
          multiline
        />
        <TextInput
          placeholder="Investimento (€)"
          style={styles.input}
          value={amount}
          onChangeText={setAmount}
          keyboardType="numeric"
        />
        <TextInput
          placeholder="Peso (%)"
          style={styles.input}
          value={weight}
          onChangeText={setWeight}
          keyboardType="numeric"
        />
        <View style={styles.modalButtons}>
          <Button title="Annulla" onPress={onClose} color="#ef4444" />
          <Button title="Salva" onPress={handleSave} />
        </View>
      </ScrollView>
    </Modal>
  );
}

function PerformanceChart() {
  const { etfs } = useContext(PortfolioContext);

  // Simulazione dati performance (mensili ultimi 12 mesi)
  const data = Array.from({ length: 12 }, (_, i) => ({
    month: `M${i + 1}`,
    value:
      8000 +
      etfs.reduce(
        (acc, etf) =>
          acc + etf.amount * (1 + 0.05 * Math.sin(i / 2 + +etf.weight / 20)),
        0
      ) *
        (i + 1) *
        0.05,
  }));

  return (
    <View style={styles.chartContainer}>
      <Text style={styles.sectionHeader}>Performance Portafoglio 12M</Text>
      <VictoryLine
        data={data}
        x="month"
        y="value"
        style={{
          data: { stroke: '#1e40af' },
          parent: { border: '1px solid #ccc' },
        }}
      />
    </View>
  );
}

function AllocationChart() {
  const { etfs } = useContext(PortfolioContext);
  const allocationData = etfs.map((etf) => ({
    x: etf.name,
    y: etf.weight,
  }));

  return (
    <View style={styles.chartContainer}>
      <Text style={styles.sectionHeader}>Asset Allocation</Text>
      <VictoryPie
        data={allocationData}
        colorScale="qualitative"
        innerRadius={50}
        labelRadius={70}
        style={{ labels: { fontSize: 12, fill: '#0f172a' } }}
      />
    </View>
  );
}

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);
  const [editableETF, setEditableETF] = useState(null);

  const openModalForEdit = (etf) => {
    setEditableETF(etf);
    setModalVisible(true);
  };

  const openModalForAdd = () => {
    setEditableETF(null);
    setModalVisible(true);
  };

  return (
    <PortfolioProvider>
      <SafeAreaView style={styles.container}>
        <ScrollView>
          <Dashboard />
          <PerformanceChart />
          <AllocationChart />
          <ETFList onEdit={openModalForEdit} />
          <TouchableOpacity style={styles.addButton} onPress={openModalForAdd}>
            <Text style={styles.addButtonText}>+ Aggiungi ETF</Text>
          </TouchableOpacity>
          <ETFModal
            visible={modalVisible}
            onClose={() => setModalVisible(false)}
            etfToEdit={editableETF}
          />
        </ScrollView>
      </SafeAreaView>
    </PortfolioProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 16,
  },
  dashboard: {
    marginBottom: 20,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1e40af',
    textAlign: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  summaryCard: {
    backgroundColor: '#e0e7ff',
    width: '48%',
    marginVertical: 6,
    padding: 16,
    borderRadius: 12,
  },
  metricLabel: {
    fontSize: 16,
    color: '#334155',
    marginBottom: 6,
    fontWeight: '600',
  },
  metricValue: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1e40af',
  },
  sectionHeader: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 10,
    color: '#1e40af',
  },
  etfListContainer: {
    marginTop: 20,
  },
  searchInput: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 8,
    borderColor: '#ccd5e0',
    borderWidth: 1,
    marginBottom: 10,
  },
  etfItem: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  etfName: {
    fontWeight: '700',
    fontSize: 16,
    color: '#0f172a',
  },
  etfDetails: {
    color: '#64748b',
    fontSize: 14,
    marginVertical: 2,
  },
  etfDescription: {
    color: '#475569',
    fontStyle: 'italic',
    fontSize: 13,
  },
  etfAmounts: {
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  modalContent: {
    padding: 20,
    backgroundColor: '#f8fafc',
    flexGrow: 1,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 20,
    color: '#1e40af',
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    borderColor: '#ccd5e0',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 15,
    padding: 12,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  addButton: {
    backgroundColor: '#1e40af',
    marginTop: 15,
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  chartContainer: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 16,
    marginBottom: 20,
  },
});
