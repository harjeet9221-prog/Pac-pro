# 📊 PAC Pro Dashboard

Applicazione mobile sviluppata in **React Native + Expo** per il monitoraggio di portafogli ETF e Piani di Accumulo (PAC).

## 🚀 Funzionalità
- Gestione dinamica ETF
- Grafici interattivi di performance e asset allocation
- Modal per aggiungere/modificare ETF
- Calcolo TER medio e valore totale portafoglio

## 🛠 Installazione e utilizzo
